import axios from 'axios';

export const FETCH_PRODUCT_DATA = 'FETCH_PRODUCT_DATA';
export const FETCH_CART_DATA = 'FETCH_CART_DATA';
export const ADD_TO_CART_SUCCESS = 'ADD_TO_CART_SUCCESS';
export const DELETE_CART_PRODUCT_SUCCESS = 'DELETE_CART_PRODUCT_SUCCESS';
export const UNLOAD_ADD_TO_CART = 'UNLOAD_ADD_TO_CART';
export const UNLOAD_DELETE_TO_CART = 'UNLOAD_DELETE_TO_CART';


export function fetchProductData() {
  return dispatch => {
    axios.get("http://5cb46eaabbf7b50014cab993.mockapi.io/api/v1/product")
    .then(response => dispatch({type: FETCH_PRODUCT_DATA, data: response.data}));
  };
};

export function fetchCartData() {
  return dispatch => {
    axios.get("http://5cb46eaabbf7b50014cab993.mockapi.io/api/v1/cart")
    .then(response => dispatch({type: FETCH_CART_DATA, data: response.data}));
  };
};

export function addToCart(params) {
  return dispatch => {
    axios.post('http://5cb46eaabbf7b50014cab993.mockapi.io/api/v1/cart', params )
    .then(response => dispatch({type: ADD_TO_CART_SUCCESS, data: response.data}));
  };
};

export function unloadAddToCart() {
  return dispatch => {
    dispatch({type: UNLOAD_ADD_TO_CART});
  };
}

export function deleteCartProduct(id) {
  return dispatch => {
    axios.delete(`http://5cb46eaabbf7b50014cab993.mockapi.io/api/v1/cart/${id}`)
    .then(response => dispatch({type: DELETE_CART_PRODUCT_SUCCESS, data: response.data}));
  };
};

export function unloadDeleteToCart() {
  return dispatch => {
    dispatch({type: UNLOAD_DELETE_TO_CART});
  };
}