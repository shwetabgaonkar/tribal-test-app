import React, {Component} from 'react';
import productImage from '../img/product-image-small.jpg';

export default class ProductSmallTile extends Component {
  constructor() {
    super();
  }
  
  render() {
    return(
		<div className="col-5">
		  <img src={productImage} style={{"width":"30%"}} />
		  <p className="product-name">Lorem Ipsum</p>
		  <p><i className="fa fa-star"></i> <i className="fa fa-star"></i> <i className="fa fa-star"></i> <i className="fa fa-star"></i> <i className="fa fa-star disable"></i> <span>4.5 / 5</span></p>
		  <a className="cta-button-small alignTextCenter">ADD TO BASKET</a>
		</div>
    );
  }
}