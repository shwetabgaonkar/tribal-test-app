import React, {Component, Fragment} from 'react';
import {connect} from 'react-redux';
import PropTypes from 'prop-types';
import productImage from '../img/product-image-small.jpg';
import productImageLarge from '../img/product-image-large.jpg';
import axios from 'axios';
import {fetchProductData, addToCart, fetchCartData, unloadAddToCart} from '../actions/actions';

class ProductDetails extends Component {
  constructor() {
    super();
	this.state={
		productData:undefined
	}	
  }
  
  componentDidMount() {
    this.props.dispatch(fetchProductData());
  }
  
  componentWillReceiveProps(props) { 
    if(props.data) {
      this.setState({productData: props.data[0]});
    }
	if(props.addToCartSuccess) {
	  this.props.dispatch(fetchCartData());
	  this.props.dispatch(unloadAddToCart());
	}
  }
  
  onAddToCart() {
	const {productData} = this.state;
	const offerAmount = productData.priceWithoutDisc * (productData.discountPercent/100);
	const addToCartParams = {
	  productName:productData.productName,
	  price:parseFloat((productData.priceWithoutDisc - offerAmount).toFixed(2)),
	  company:productData.company,
	  model:productData.model	  
	}
	this.props.dispatch(addToCart(addToCartParams));
  }
  
  zoomIn(event) {
	  var element = document.getElementById("overlay");
	  element.style.display = "inline-block";
	  var img = document.getElementById("imgZoom");
	  var posX = event.offsetX ? (event.offsetX) : event.pageX - img.offsetLeft;
	  var posY = event.offsetY ? (event.offsetY) : event.pageY - img.offsetTop;
	  element.style.backgroundPosition=(posX-30)+"px "+(-posY*1)+"px";

  }
  
  zoomOut() {
	  var element = document.getElementById("overlay");
	  element.style.display = "none";
  }
  
  render() {
	const {productData} = this.state;
	if(productData) {
		const offerAmount = productData.priceWithoutDisc * (productData.discountPercent/100);
		return(
			<Fragment>
			  <div className="product-container containerHeight overflowHide">
				  <div className="col-2 productDetailsHeight">
					<img src={productImage} id="imgZoom" style={{"width":"100%"}} onMouseMove={this.zoomIn.bind(this)} onMouseOut={this.zoomOut.bind(this)}/>
				   <div id="overlay" onMouseMove={this.zoomIn.bind(this)}></div>
				  </div>
				  <div className="col-2 detailsPanel productDetailsHeight">
					  <div className="borderBottom" >
						<span className="sub-text">{productData.company.toUpperCase()}</span><span className="product-id-text floatRight" >Lorem Ipsum: {productData.productId}</span>
						<p className="product-name">{productData.productName}</p>
						<div className="overflowHide">
							<div className='pricing'>
							  <p><span>&pound;{productData.priceWithoutDisc}</span> &pound;{(productData.priceWithoutDisc - offerAmount).toFixed(2)}</p>
							  <p className="product-id-text"><b>RRP: &nbsp;</b> &pound;{offerAmount.toFixed(3)} ({productData.productName} {productData.discountPercent}%)</p>
							</div>
							<a className='cta-button alignTextCenter cursorPointer' onClick={this.onAddToCart.bind(this)} >ADD TO BASKET</a>
						</div>
						<p className="sub-text marginTopBottom">{productData.productName.toUpperCase()}: <span>UK <span>Change</span></span></p>
						<p className="product-id-text">In stock. More than 10 available online. Order in the next 10 mins for next day delivery.</p>
						<div className="marginTopBottom product-desc"><p>Lorem ipsum dolor sit amet, consecteture adipisicing.</p>
						  <ul>
							<li>Brand: {productData.company}</li>
							<li>Model: {productData.model}</li>
							<li>Material: {productData.productName}</li>
							<li>Dimensions model: {productData.productName}</li>
						  </ul>
						</div>
					  </div>
					  <div className="ratings">
						<p><i className="fa fa-star"></i> <i className="fa fa-star"></i> <i className="fa fa-star"></i> <i className="fa fa-star"></i> <i className="fa fa-star disable"></i> <span>4.5 / 5<span>112 Lorem ipsum</span></span></p>
					  </div>
				   </div>	   
			  </div>
			</Fragment>
		);
	} else {
		return (<div><h2>Loading...</h2></div>);
	}
	
  }
}

ProductDetails.propTypes = {
  data: PropTypes.array
};

function mapStateToProps(state) {
  return {
    data: state.data.productData,
	addToCartSuccess:state.data.addToCartSuccess
  };
}
export default connect(mapStateToProps)(ProductDetails);