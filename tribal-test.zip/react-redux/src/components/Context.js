import React from 'react'

export const ReactReduxContext = React.createContext(null)

export default ReactReduxContext
